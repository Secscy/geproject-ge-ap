import openpyxl
import os
import sys 
from datetime import datetime
import copy
from pprint import pprint
import tkinter as tk
from tkinter import messagebox


# Importando o arquivo principal do robô.
# ATENÇÃO: É NECESSÁRIO QUE executar_automacao AGORA RETORNE UMA TUPLA COM 3 ITENS:
# (sucesso_bool, motivo_falha_str, numero_guia_str | None)
from geap_medhome_main import executar_automacao

# --- Configurações ---
# O robô agora procura por uma planilha .xlsx dentro desta pasta.
PASTA_RODAR = "RodarEstes"
ARQUIVO_XLSX = None # O nome do arquivo será descoberto automaticamente
# A aba é agora uma lista de nomes possíveis que o robô irá testar
NOMES_ABAS_POSSIVEIS = ["Planilha1", "Dados dos Clientes"]
# Nomes das pastas onde as planilhas serão salvas.
PASTA_SUCESSO = "Planilhas de Sucesso"
PASTA_REJEITADAS = "Planilhas Rejeitadas"
PASTA_TENTAR_DE_NOVO = "Planilhas Clientes Tentar Novamente"


def carregar_mapa_procedimentos():
    """
    Lê o arquivo de referência 'codigosProcedimentos.xlsx' e retorna um 
    dicionário mapeando {código: descrição} para consulta rápida.
    """
    caminho = os.path.join(os.getcwd(), "codigosProcedimentos.xlsx")
    mapa = {}
    
    if not os.path.exists(caminho):
        print(f"[AVISO] Arquivo '{caminho}' não encontrado. O Campo 26 ficará vazio.")
        return mapa

    try:
        # Abre o arquivo de referência
        wb_ref = openpyxl.load_workbook(caminho, data_only=True)
        ws_ref = wb_ref.active # Assume que os dados estão na primeira aba
        
        # Itera pelas linhas da planilha de códigos
        for row in ws_ref.iter_rows(min_row=1):
            cod_val = row[0].value
            desc_val = row[1].value
            
            if cod_val is not None:
                # Limpa o código para garantir que a comparação funcione (remove .0 de floats, etc)
                cod_str = str(int(cod_val)) if str(cod_val).strip().replace('.', '').isdigit() else str(cod_val).strip()
                mapa[cod_str] = str(desc_val).strip() if desc_val else ""
                
        print(f"[OK] {len(mapa)} procedimentos carregados para referência.")
        return mapa
    except Exception as e:
        print(f"[ERRO] Falha ao carregar mapa de procedimentos: {e}")
        return mapa
    

def gerar_planilha_recovery(clientes_pendentes):
    """
    Gera uma nova planilha RECOVERY_ na pasta PASTA_RODAR com os clientes que restam.
    """
    if not clientes_pendentes:
        print("Atenção: Interrupção ocorreu, mas não havia clientes pendentes para salvar no arquivo de Recovery.")
        return

    # O nome do arquivo é construído com o prefixo RECOVERY_ e a data/hora atual
    nome_arquivo_recovery = f"RECOVERY_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
    caminho_completo = os.path.join(os.getcwd(), PASTA_RODAR, nome_arquivo_recovery)
    
    # Prepara a estrutura do arquivo de planilha (workbook)
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Dados dos Clientes"
    
    # Define o cabeçalho (Deve ser igual ao cabeçalho de entrada)
    headers = ['Paciente', '4-Data da Autorização (ver email)', '5-Senha = # autorizacao (ver email)', '8-Número da Carteira', '25-Código do Procedimento ou Item assistencial', '27-Qtde Solic.', '47-Valor Unitário']
    ws.append(headers)
    
    # Itera sobre os clientes pendentes
    for cliente in clientes_pendentes:
        dados_cliente = cliente.get('procedimentos', [])
        if not dados_cliente:
            continue
            
        # Para cada procedimento do cliente (linha na planilha original)
        for i, procedimento in enumerate(dados_cliente):
            row_data = [
                # Apenas a primeira linha do cliente tem o nome, senha e carteira preenchidos
                procedimento.get('Paciente', '') if i == 0 else None,
                procedimento.get('4-Data da Autorização (ver email)', '') if i == 0 else None,
                # Usa a senha completa (com o título de cabeçalho)
                procedimento.get('5-Senha', '') if i == 0 else None,
                procedimento.get('8-Número da Carteira', '') if i == 0 else None,
                
                # Campos de procedimento (sempre preenchidos)
                procedimento.get('25-Código do Procedimento ou Item assistencial', ''),
                procedimento.get('27-Qtde Solic.', ''),
                procedimento.get('47-Valor Unitário', '')
            ]
            
            # Note: O CBO não é inserido aqui porque ele é um campo fixo interno e
            # não faz parte do cabeçalho da planilha de entrada/recovery.
            ws.append(row_data)

    try:
        wb.save(caminho_completo)
        print(f"\n[!!! RECOVERY !!!] Planilha de recuperação salva em '{os.path.basename(caminho_completo)}' em '{PASTA_RODAR}'.")
        print("Ao reiniciar o programa, este arquivo será priorizado.")
    except Exception as e:
        print(f"\n[ERRO RECOVERY] Falha ao salvar o arquivo de recuperação: {e}")

def ler_e_preparar_dados(caminho_arquivo):
    """
    Lê o arquivo XLSX do cliente, preenche os dados ausentes e agora
    também busca a descrição do procedimento no arquivo de referência.
    """
    if not os.path.exists(caminho_arquivo):
        print(f"Erro: O arquivo '{caminho_arquivo}' não foi encontrado.")
        return None

    # Carrega o mapa de descrições antes de começar o processamento
    mapa_descricoes = carregar_mapa_procedimentos()

    try:
        wb = openpyxl.load_workbook(caminho_arquivo, data_only=True)
        
        ws = None
        for nome_aba in NOMES_ABAS_POSSIVEIS:
            if nome_aba in wb.sheetnames:
                ws = wb[nome_aba]
                print(f"Aba encontrada: '{nome_aba}'")
                break
        
        if ws is None:
            nomes_possiveis = " ou ".join(NOMES_ABAS_POSSIVEIS)
            print(f"Erro: Nenhuma das abas '{nomes_possiveis}' existe no arquivo.")
            return None
        
        header = [cell.value for cell in ws[1]]
        header_map = {col: i for i, col in enumerate(header)}

        colunas_obrigatórias = [
            'Paciente',
            '4-Data da Autorização (ver email)',
            '5-Senha = # autorizacao (ver email)',
            '8-Número da Carteira',
            '25-Código do Procedimento ou Item assistencial',
            '27-Qtde Solic.',
            '47-Valor Unitário'
        ]

        if not all(col in header_map for col in colunas_obrigatórias):
            print("Erro: O arquivo não contém todas as colunas obrigatórias.")
            return None

        clientes_para_automacao = []
        cliente_atual = None
        paciente_anterior = None
        
        for row in ws.iter_rows(min_row=2):
            paciente_raw = row[header_map.get('Paciente')].value
            data_autorizacao_raw = row[header_map.get('4-Data da Autorização (ver email)')].value 
            senha_raw = row[header_map.get('5-Senha = # autorizacao (ver email)')].value
            num_carteira_raw = row[header_map.get('8-Número da Carteira')].value
            cod_procedimento_raw = row[header_map.get('25-Código do Procedimento ou Item assistencial')].value 
            qtde_solicitada_raw = row[header_map.get('27-Qtde Solic.')].value 
            valor_unitario_raw = row[header_map.get('47-Valor Unitário')].value 

            if paciente_raw is not None and paciente_raw != paciente_anterior:
                if cliente_atual and cliente_atual['procedimentos']:
                    clientes_para_automacao.append(copy.deepcopy(cliente_atual))
                
                cliente_atual = {
                    'Paciente': paciente_raw,
                    'data_autorizacao': data_autorizacao_raw,
                    'senha': str(int(senha_raw)) if (senha_raw is not None and str(senha_raw).strip().replace('.', '').isdigit()) else (str(senha_raw) if senha_raw is not None else None),
                    'num_carteira': str(int(num_carteira_raw)) if (num_carteira_raw is not None and str(num_carteira_raw).strip().replace('.', '').isdigit()) else (str(num_carteira_raw) if num_carteira_raw is not None else None),
                    'cbo': '225118',
                    'procedimentos': []
                }
            
            if cod_procedimento_raw is not None and cliente_atual:
                
                qtde_solicitada_str = str(int(qtde_solicitada_raw)) if (qtde_solicitada_raw is not None and str(qtde_solicitada_raw).strip().replace('.', '').isdigit()) else '0'
                
                # Prepara o código limpo para busca e preenchimento
                cod_limpo = str(int(cod_procedimento_raw)) if str(cod_procedimento_raw).strip().replace('.', '').isdigit() else str(cod_procedimento_raw)
                
                # Busca a descrição no mapa carregado
                descricao_procedimento = mapa_descricoes.get(cod_limpo, "Descrição não encontrada")
                
                procedimento = {
                    'Paciente': cliente_atual['Paciente'],
                    '4-Data da Autorização (ver email)': cliente_atual['data_autorizacao'].strftime('%d/%m/%Y') if isinstance(cliente_atual['data_autorizacao'], datetime) else str(cliente_atual['data_autorizacao']),
                    '5-Senha': cliente_atual['senha'],
                    '8-Número da Carteira': cliente_atual['num_carteira'],
                    '19-Codigo CBO': cliente_atual['cbo'],
                    
                    '25-Código do Procedimento ou Item assistencial': cod_limpo,
                    # NOVO CAMPO ADICIONADO AQUI:
                    '26-DescProcd': descricao_procedimento,
                    
                    '27-Qtde Solic.': qtde_solicitada_str,
                    '28-Qtde Aut.': qtde_solicitada_str, # Usando a mesma qtd solicitada para autorizada
                    '47-Valor Unitário': str(valor_unitario_raw).replace('.', ',') if valor_unitario_raw is not None else '0,00'
                }
                
                cliente_atual['procedimentos'].append(procedimento)

            paciente_anterior = paciente_raw

        if cliente_atual and cliente_atual['procedimentos']:
            clientes_para_automacao.append(copy.deepcopy(cliente_atual))

        return clientes_para_automacao
        
    except Exception as e:
        print(f"Ocorreu um erro ao ler o arquivo XLSX: {e}")
        return None

def salvar_dados_em_planilha(clientes_lista, pasta, nome_arquivo, motivo_coluna=False):
    """
    Cria uma nova planilha com os dados dos clientes na pasta especificada.
    Inclui as colunas opcionais de motivo de erro e o número da guia gerada.
    (Lógica idêntica à versão funcional anterior)
    """
    if not os.path.exists(pasta):
        os.makedirs(pasta)

    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Dados dos Clientes"

    headers = ['Paciente', '4-Data da Autorização (ver email)', '5-Senha = # autorizacao (ver email)', '8-Número da Carteira', '19-Codigo CBO', '25-Código do Procedimento ou Item assistencial', '27-Qtde Solic.', '28-Qtde Aut.', '47-Valor Unitário']
    
    if motivo_coluna:
        headers.append('Motivo do Erro')
        headers.append('Guia Gerada')
    else:
        headers.append('Guia Gerada') 
        
    ws.append(headers)
    
    for cliente in clientes_lista:
        dados_cliente = cliente.get('procedimentos', [])
        motivo_erro = cliente.get('motivo', None)
        guia_gerada = cliente.get('guia_gerada', None)
        
        if not dados_cliente:
            continue
            
        primeiro_procedimento = dados_cliente[0]
        
        row_data = [
            primeiro_procedimento.get('Paciente', ''),
            primeiro_procedimento.get('4-Data da Autorização (ver email)', ''),
            primeiro_procedimento.get('5-Senha', ''),
            primeiro_procedimento.get('8-Número da Carteira', ''),
            primeiro_procedimento.get('19-Codigo CBO', ''),
            primeiro_procedimento.get('25-Código do Procedimento ou Item assistencial', ''),
            primeiro_procedimento.get('27-Qtde Solic.', ''),
            primeiro_procedimento.get('28-Qtde Aut.', ''),
            primeiro_procedimento.get('47-Valor Unitário', '')
        ]
        
        if motivo_coluna:
            row_data.append(motivo_erro)
            row_data.append(guia_gerada)
        else:
            row_data.append(guia_gerada) 
        
        ws.append(row_data)

        for procedimento in dados_cliente[1:]:
            procedimento_data = [
                None, 
                None,
                None,
                None,
                procedimento.get('19-Codigo CBO', ''),
                procedimento.get('25-Código do Procedimento ou Item assistencial', ''),
                procedimento.get('27-Qtde Solic.', ''),
                procedimento.get('28-Qtde Aut.', ''),
                procedimento.get('47-Valor Unitário', '')
            ]
            
            if motivo_coluna:
                procedimento_data.append(None) 
                procedimento_data.append(None) 
            else:
                procedimento_data.append(None) 

            ws.append(procedimento_data)

    caminho_completo = os.path.join(pasta, nome_arquivo)
    
    wb.save(caminho_completo)
    print(f"Os dados foram salvos no arquivo '{caminho_completo}'.")

if __name__ == "__main__":
    
    # --- Passo 1: Encontrar o arquivo na pasta 'RodarEstes' ---
    caminho_pasta_rodar = os.path.join(os.getcwd(), PASTA_RODAR)
    
    if not os.path.exists(caminho_pasta_rodar):
        print(f"A pasta '{PASTA_RODAR}' não foi encontrada. Criando agora...")
        try:
            os.makedirs(caminho_pasta_rodar)
            print(f"A pasta RodarEstes foi criada em: {caminho_pasta_rodar}")
            print("Favor iniciar o programa novamente.")
            sys.exit(0)
        except Exception as e:
            print(f"Erro ao criar a pasta '{PASTA_RODAR}': {e}")
            input("Enter para encerrar o programa")
            sys.exit(1)
            
    print(f"A pasta '{PASTA_RODAR}' foi encontrada em: {caminho_pasta_rodar}") 
    input("Pressione ENTER para continuar a busca pela planilha...") 
    
    
    # --- Lógica de Priorização (Recovery > Padrão) ---
    arquivos_na_pasta = os.listdir(caminho_pasta_rodar)
    arquivos_xlsx = [f for f in arquivos_na_pasta if f.endswith(".xlsx")]
    
    arquivos_recovery = [f for f in arquivos_xlsx if f.startswith("RECOVERY_")]
    
    if arquivos_recovery:
        # Encontrar o arquivo de recovery mais recente pela data de criação (ctime)
        arquivos_recovery_com_caminho = [os.path.join(caminho_pasta_rodar, f) for f in arquivos_recovery]
        ARQUIVO_XLSX = max(arquivos_recovery_com_caminho, key=os.path.getctime)
        print(f"Planilha de RECOVERY mais recente encontrada: '{os.path.basename(ARQUIVO_XLSX)}'")
    elif arquivos_xlsx:
        # Se não houver recovery, pega o primeiro arquivo .xlsx padrão
        arquivos_standard = [f for f in arquivos_xlsx if not f.startswith("RECOVERY_")]
        if arquivos_standard:
            # Pega o primeiro arquivo .xlsx que não seja de recovery
            ARQUIVO_XLSX = os.path.join(caminho_pasta_rodar, arquivos_standard[0])
            print(f"Planilha padrão encontrada: '{os.path.basename(ARQUIVO_XLSX)}'")
    
    if ARQUIVO_XLSX is None:
        print(f"Erro: Nenhuma planilha .xlsx foi encontrada na pasta '{PASTA_RODAR}'.")
    else:
        print("Iniciando a automação...")
        print("-------------------------")
        
    clientes_para_automacao = None
    clientes_que_passaram = []
    clientes_com_erro_automacao = []
    clientes_nao_processados = []
    clientes_para_recovery = [] # Lista usada para rastrear o progresso
    
    if ARQUIVO_XLSX:
        # --- Passo 2: Ler e preparar os dados do arquivo XLSX encontrado ---
        clientes_para_automacao = ler_e_preparar_dados(ARQUIVO_XLSX)
        
        # CRÍTICO: Cria a cópia extra para ser usada pelo sistema de Recovery
        if clientes_para_automacao is not None:
             clientes_para_recovery = copy.deepcopy(clientes_para_automacao)

    if clientes_para_automacao is not None:
        if clientes_para_automacao:
            
            # --- Passo 3: Iterar sobre cada cliente e chamar o robô de automação ---
            
            for i, dados_cliente in enumerate(clientes_para_automacao):
                
                try:
                    if dados_cliente['senha'] is not None and dados_cliente['data_autorizacao'] is not None and dados_cliente['num_carteira'] is not None:
                        print(f"\n--- Processando cliente {i+1}: {dados_cliente['Paciente']} ---")
                        
                        print("Dados do cliente antes da automação:")
                        pprint(dados_cliente)
                        print("\n-----------------------------------")
                        
                        automacao_ok, motivo_falha, numero_guia = executar_automacao(dados_cliente['procedimentos'], len(dados_cliente['procedimentos']))
                        
                        dados_cliente['guia_gerada'] = numero_guia
                        
                        if automacao_ok:
                            print(f"Cliente {dados_cliente['Paciente']} processado com sucesso! Guia gerada: {numero_guia}")
                            clientes_que_passaram.append(dados_cliente)
                        else:
                            print(f"PULANDO para o próximo cliente devido a um erro na automação do cliente {i+1}. Motivo: {motivo_falha}")
                            clientes_com_erro_automacao.append({
                                'procedimentos': dados_cliente['procedimentos'],
                                'motivo': motivo_falha,
                                'guia_gerada': numero_guia 
                            })
                    else:
                        print(f"\n--- Cliente {dados_cliente['Paciente']} tem dados de leitura faltando, pulando para o próximo ---")
                        clientes_com_erro_automacao.append({
                            'procedimentos': dados_cliente['procedimentos'],
                            'motivo': 'Falta de dados (Senha, Data Autorização ou Carteira)',
                            'guia_gerada': None 
                        })
                        
                    # CRÍTICO PARA RECOVERY: Remove o cliente da lista de recovery
                    # pois ele foi EXECUTADO (sucesso ou falha não importa)
                    if clientes_para_recovery:
                        clientes_para_recovery.pop(0)

                except Exception as e:
                    # Registra o erro completo no console para debug
                    print(f"A automação foi interrompida com um erro: {e}")
                    
                    # Salva a lista restante como um arquivo de recovery
                    if clientes_para_recovery:
                        gerar_planilha_recovery(clientes_para_recovery)
                    
                    # Captura os clientes restantes (para o arquivo TENTAR_DE_NOVO se houver)
                    clientes_nao_processados = clientes_para_automacao[i:]
                    print(f"Salvos {len(clientes_nao_processados)} clientes não processados (e gerado Recovery).")


                    # --- LÓGICA DE ALERTA CONDICIONAL ---
                    
                    # Converte o erro 'e' para string e verifica se é o Failsafe
                    erro_string = str(e)
                    mensagem_alerta = ""
                    titulo_alerta = "Automação Interrompida!"
                    
                    if "fail-safe triggered" in erro_string:
                        # Se for Failsafe, mostra a mensagem amigável
                        mensagem_alerta = "O robô foi desativado pelo usuário (movimento do mouse no canto da tela).\n"
                        titulo_alerta = "Interrupção pelo Usuário"
                    else:
                        # Para qualquer outro erro (ex: imagem não encontrada, erro de planilha)
                        # Mantém o erro técnico para facilitar o diagnóstico
                        titulo_alerta = "Erro!!"
                        mensagem_alerta = f"O robô foi interrompido ou parou de funcionar inesperadamente.\n\nMotivo do Erro: {e}\n"

                    # 2. Exibe o alerta
                    root = tk.Tk()
                    root.withdraw() 
                    
                    messagebox.showerror(
                        titulo_alerta, 
                        mensagem_alerta
                    )
                    root.destroy()
                    # --- FIM LÓGICA DE ALERTA CONDICIONAL ---

                    break # Interrompe o loop
            
            # --- Passo 4: Salvar os resultados e checar limpeza do Recovery ---
            
            # Salva os clientes que passaram
            if clientes_que_passaram:
                nome_arquivo_passou = f"clientes_que_passaram_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
                salvar_dados_em_planilha(clientes_que_passaram, PASTA_SUCESSO, nome_arquivo_passou)
            else:
                print("Nenhum cliente processado com sucesso.")

            # Salva os clientes com erro
            if clientes_com_erro_automacao:
                nome_arquivo_erro = f"clientes_com_erro_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
                salvar_dados_em_planilha(clientes_com_erro_automacao, PASTA_REJEITADAS, nome_arquivo_erro, motivo_coluna=True)
            else:
                print("Nenhum cliente com erro encontrado.")

            # Salva os clientes que restaram em caso de interrupção
            if clientes_nao_processados:
                nome_arquivo_tentar_denovo = f"clientes_nao_processados_{datetime.now().strftime('%Y%m%d_%H%M%S')}.xlsx"
                salvar_dados_em_planilha(clientes_nao_processados, PASTA_TENTAR_DE_NOVO, nome_arquivo_tentar_denovo)
            
            # Se a automação completou o loop SEM interrupção e usou um arquivo de Recovery,
            # ele deve ser renomeado/movido para evitar que seja rodado novamente.
            if not clientes_nao_processados and ARQUIVO_XLSX and os.path.basename(ARQUIVO_XLSX).startswith("RECOVERY_"):
                caminho_original = ARQUIVO_XLSX
                novo_nome = caminho_original.replace("RECOVERY_", "COMPLETADO_")
                try:
                    os.rename(caminho_original, novo_nome)
                    print(f"\n[SUCESSO] Arquivo de Recovery renomeado para '{os.path.basename(novo_nome)}' após conclusão.")
                except Exception as e:
                    print(f"\n[ATENÇÃO] Não foi possível renomear o arquivo de Recovery: {e}")


        else:
            print("Planilha lida, mas não continha dados válidos de clientes para processar. A automação não será iniciada.")
    else:
        print("Nenhum dado válido para processar. A automação não será iniciada (Erro na leitura da planilha).")

    print("\nFim da Automação")
    input("Aperte Enter para Fechar")

#By Maya&Zars
