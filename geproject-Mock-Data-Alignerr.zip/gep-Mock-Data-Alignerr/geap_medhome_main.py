import json
import pyautogui 
import time 
import sys 
import os 
import pyperclip # Adicionado para manipulação do clipboard na função salvar_guia_prestador 
import re #idem, regex

# --- Configurações Iniciais --- 
# Dica de segurança: PyAutoGUI tem um modo de segurança 
# se você mover o mouse para o canto superior esquerdo da tela, 
# o programa vai parar. Isso é útil para cancelar a automação. 
pyautogui.FAILSAFE = True 

# Váriavel global para controlar se a validação inicial já foi feita. 
# O underscore inicial indica que ela é uma variável interna do módulo. 
_VALIDACAO_FEITA = False  

def encontrar_e_clicar(nome_imagem, mensagem_sucesso, confidence=0.8): 
    """ 
    Função auxiliar para encontrar uma imagem e clicar nela. 
    Retorna True se a imagem foi encontrada e o clique foi feito, caso contrário, retorna False. 
    """ 
    print(f"Procurando o campo '{nome_imagem}' na tela...") 
    try: 
        # Ajustando a confiança para lidar com pequenas variações na imagem na tela 
        # O parâmetro 'confidence' permite uma tolerância para a diferença de pixels. 
        # Estamos mantendo o 'grayscale=True' para ignorar variações de cores. 
        localizacao = pyautogui.locateOnScreen(nome_imagem, confidence=confidence, grayscale=True) 
        if localizacao is not None: 
            x, y = pyautogui.center(localizacao) 
            print(f"'{nome_imagem}' encontrado em: x={x}, y={y}") 
            pyautogui.click(x, y) 
            print(mensagem_sucesso) 
            return True 
        else: 
            print(f"Erro: Não foi possível encontrar a imagem '{nome_imagem}' na tela.") 
            return False 
    except Exception as e: 
        print(f"Ocorreu um erro ao procurar '{nome_imagem}': {e}") 
        #input(f"Não consegui encontrar o {nome_imagem}, favor encerrar o programa (CTRL + C)") 

        return False 

def carregar_coordenadas():
    with open("coordenadas.json", "r") as f:
        return json.load(f)

# Carregue uma vez no início da automação
coords = carregar_coordenadas()

# Exemplo de como substituir a função encontrar_e_clicar:
def clicar_por_coordenada(nome_botao):
    
    time.sleep(3) 

    if nome_botao in coords:
        x = coords[nome_botao]["x"]
        y = coords[nome_botao]["y"]
        pyautogui.click(x, y)
        print(f"Clicado em {nome_botao} nas coordenadas {x}, {y}")
        return True
    return False


def encontrar_imagem_na_tela(imagem): 

    """ 
    Verifica se a imagem 'senhaInvalida.jpg' está na tela. 
    Retorna True se a imagem for encontrada, e False caso contrário. 
    """ 
    try: 
        # Tenta encontrar a imagem. Se encontrar, a execução continua. 
        pyautogui.locateOnScreen(imagem) 
        
        # Se a imagem for encontrada, este bloco é executado. 
        print(f"A imagem {imagem} foi encontrada.") 
        return True 
    
    except Exception as e: 
        # Se a exceção for capturada (imagem não encontrada), este bloco é executado. 
        print(e) 
        print(f"Não achei a imagem {imagem}.") 
        return False 


def aguardar_tela_carregamento(): 
    """Espera até que a tela de carregamento desapareça, procurando uma imagem específica.""" 
    while (True): 
        if(encontrar_imagem_na_tela('aguardarEstaNaTela.jpg')): 
            time.sleep(1) 
        else: 
            break 


def limpar_tela(): 
    """ 
    Função que aperta o botão 'Limpar Tela' usando a técnica de foco via DevTools. 
    """ 
    time.sleep(1)
    # 1. Abre o F12 e aguarda o painel carregar
    if clicar_por_coordenada("botaoLimpar"):
        print("")
    else:
        print("Não consegui clicar no botão Limpar")
        print("Troque a imagem botaoLimpar.jpg e reinicie o programa por favor.")
        input("Aperte Enter duas vezes para gerar as planilhas de recovery")
        input("Aperte Enter duas vezes para gerar as planilhas de recovery")
        # Levantamos um erro para o script principal capturar e salvar o recovery
        raise Exception("Botão Limpar não encontrado na tela.")
    time.sleep(1)


def apertar_repetir_dados_executante(): 
    """Clica no botão para repetir os dados do executante.""" 
    # 1. Abre o F12 e aguarda o painel carregar
    pyautogui.hotkey('f12')
    time.sleep(1)

    # 2. Abre a busca no Elements e digita o ID específico
    pyautogui.hotkey('ctrl', 'f')
    time.sleep(0.2) 
    pyautogui.typewrite('DadosSolicitanteUC_lnkDadosLogin', interval=0.01)
    
    # 3. Aguarda o highlight do seletor
    time.sleep(0.5)

    # 4. Sai da barra de busca para focar no código do elemento
    pyautogui.press('esc')
    time.sleep(0.2)

    # 5. Abre o menu de contexto (Botão Direito)
    pyautogui.hotkey('shift', 'f10')
    time.sleep(0.3)

    # 6. Desce até a opção 'Focus' (15 vezes) e confirma
    pyautogui.press('up', presses=4, interval=0.05)
    pyautogui.press('enter')
    
    # 7. Curta pausa para garantir o foco no input real da página
    time.sleep(0.1)
    pyautogui.press('enter')


    print("Repetir dados do Executante clicado.") 
    pyautogui.press('tab') 


def salvar_guia(): 
    """ 
    Tenta salvar a guia e verifica o resultado. 
    Retorna True se a guia foi salva, False caso contrário. 
    """ 
    time.sleep(1)
    # 1. Tenta clicar no botão salvar
    if clicar_por_coordenada("botaoSalvar"):
        print("")
    else:
        print("Não consegui clicar no botão Salvar")
        print("Troque a imagem botaoSalvar.jpg e reinicie o programa por favor.")
        input("Aperte Enter duas vezes para gerar as planilhas de recovery")
        input("Aperte Enter duas vezes para gerar as planilhas de recovery")
        # Dispara o erro que aciona o recovery no geap_ler_planilhas.py
        raise Exception("Botão Salvar não encontrado na tela.")
    time.sleep(3)

    if verifica_se_foi_salvo(): 
        print("A Guia foi Salva") 
        time.sleep(1) 
        return True 
    else: 
        print("A guia não foi salva, gerando erro e partindo pro próximo cliente") 
        return False
    
def capturar_texto_guia_observacao():
    """
    Função auxiliar criada com a sua lógica:
    Foca no campo observação, dá Shift+Tab e copia tudo.
    """
    # Limpa a área de transferência
    pyperclip.copy('')
    
    # Foca no campo de observação usando a função que já existe
    #focar_em_campo('ProcedimentosRealizadosUC1_lnkIncluirProcedimento')

    #Esquema do ctrl f "Atendimento a RN" e esc depois pra focar no que precisamos
    with pyautogui.hold('ctrl'): 
        pyautogui.press(['f']) 
    time.sleep(0.5)
    pyautogui.typewrite('Atendimento a RN', interval=0.01)
    

    pyautogui.press(['esc']) 
    time.sleep(0.3)
    
    # Dá Shift + Tab 1 vez conforme o seu teste
    #with pyautogui.hold('shift'): 
    #    pyautogui.press(['tab']) 
    #time.sleep(0.5)


    # Seleciona tudo e copia
    pyautogui.hotkey('ctrl', 'a')
    time.sleep(0.3)
    pyautogui.hotkey('ctrl', 'c')
    time.sleep(0.3)
    
    pyautogui.press(['home']) 
    time.sleep(0.1)
    pyautogui.press(['home']) 
    time.sleep(0.1)
    pyautogui.press(['home']) 
    time.sleep(0.1)
    
    # Tira a seleção da tela
    pyautogui.press('right')
    
    return pyperclip.paste().lower()


def verifica_se_foi_salvo():
    texto_copiado = capturar_texto_guia_observacao()
    
    if 'com sucesso' in texto_copiado:
        print("A Guia foi Salva") 
        time.sleep(1) 
        return True
    else:
        time.sleep(1)
        return False


def salvar_guia_prestador(): 
    """ 
    Extrai o número da guia do prestador inspecionando o elemento via DevTools (F12),
    copiando o HTML do elemento e extraindo o valor do atributo 'value'.
    """ 
    print("--- Iniciando a extração da Guia via DOM (F12) ---") 
    
    try:
        # 1. Abre o F12 e aguarda
        pyautogui.hotkey('f12')
        time.sleep(1)

        # 2. Busca o ID específico no Elements
        pyautogui.hotkey('ctrl', 'f')
        time.sleep(0.2)
        pyautogui.typewrite('CabecalhoGuiaUC_txtNumeroGuia', interval=0.01)
        time.sleep(0.5)

        # 3. Foca no elemento encontrado
        pyautogui.press('esc')
        time.sleep(0.2)

        # 4. Menu de contexto (Botão Direito)
        pyautogui.hotkey('shift', 'f10')
        time.sleep(0.3)

        # 5. Navega até 'Copiar' > 'Copiar elemento'
        # Desce 6 vezes até "Copy" (ou similar)
        pyautogui.press('down', presses=6, interval=0.1)
        # Abre o submenu de cópia
        pyautogui.press('right')
        time.sleep(0.1)
        # Seleciona "Copy element" (geralmente é o primeiro do submenu)
        pyautogui.press('enter')
        time.sleep(0.5)

        # 6. Captura o HTML do clipboard
        html_elemento = pyperclip.paste().strip()
        
        # 7. Fecha o F12 para limpar a tela
        pyautogui.hotkey('f12')
        time.sleep(0.5)

        # 8. Extrai o número usando Regex
        # Procura por: value="qualquer_coisa"
        match = re.search(r'value="([^"]+)"', html_elemento)
        
        if match:
            numero_da_guia = match.group(1)
            print("\n------------------------------------------------------------") 
            print(f"SUCESSO: Número da Guia Extraído: {numero_da_guia}") 
            print("------------------------------------------------------------\n") 
            return True, numero_da_guia
        else:
            motivo = "Não foi possível encontrar o atributo 'value' no HTML copiado."
            print(f"FALHA: {motivo}")
            print(f"Conteúdo recebido: {html_elemento[:100]}...") # Log parcial para debug
            return False, motivo

    except Exception as e:
        motivo = f"Erro inesperado durante a extração: {e}" 
        print(f"FALHA: {motivo}") 
        return False, motivo

def finalizar_guia(): 
    """ 
    Tenta finalizar a guia e verifica o resultado. 
    Retorna True se a guia foi finalizada, False caso contrário. 
    """ 
    time.sleep(1)
    # 1. Tenta clicar no botão finalizar
    if clicar_por_coordenada("botaoFinalizar"):
        print("")
    else:
        print("Não consegui clicar no botão Finalizar")
        print("Troque a imagem botaoFinalizar.jpg e reinicie o programa por favor.")
        input("Aperte Enter duas vezes para gerar as planilhas de recovery")
        input("Aperte Enter duas vezes para gerar as planilhas de recovery")
        # Dispara o erro para garantir que os dados pendentes sejam salvos no Recovery
        raise Exception("Botão Finalizar não encontrado na tela.")
    time.sleep(3)

    if verifica_se_foi_finalizado(): 
        print("A Guia foi Finalizada") 
        time.sleep(1) 
        return True 
    else: 
        print("A guia não foi finalizada, gerando erro e partindo pro próximo cliente") 
        return False
    

    
def verifica_se_foi_finalizado():
    texto_copiado = capturar_texto_guia_observacao()
    
    # Busca pela string exata que o sistema retorna
    if 'finalizada com sucesso' in texto_copiado:
        print("A Guia foi Finalizada") 
        time.sleep(1) 
        return True
    else:
        time.sleep(1)
        return False
    
def salvar_finalizar(): 
    """ 
    Função para salvar e finalizar a guia em sequência. 
    
    Retorna: 
      (True, numero_da_guia) em caso de sucesso. 
      (False, motivo_falha) em caso de falha. 
    """ 
    #input("Enter para continuar")
    # 1. Tenta salvar a guia 
    if not salvar_guia(): 
        limpar_tela() 
        return False, "Guia não salva" 

    # 2. Tenta extrair o número da guia do prestador 
    sucesso_prestador, motivo_ou_guia = salvar_guia_prestador() 
    
    if not sucesso_prestador: 
        limpar_tela() 
        # Se falhou, 'motivo_ou_guia' contém a descrição da falha 
        return False, f"Guia do prestador não salva/extraída: {motivo_ou_guia}" 

    # Se chegou aqui, conseguimos extrair o número da guia. 
    numero_da_guia = motivo_ou_guia 
    
    # 3. Tenta finalizar a guia 
    if not finalizar_guia(): 
        limpar_tela() 
        # Falha na finalização, mas o número da guia extraído é útil 
        # O chamador (executar_automacao) vai lidar com este retorno como falha geral.
        return False, f"Guia não finalizada. Guia extraída: {numero_da_guia}" 

    # 4. Se tudo deu certo, limpa a tela e retorna sucesso com o número da guia 
    limpar_tela() 
    time.sleep(2) 
    return True, numero_da_guia 

def verificar_validacao():
    # Começa clicando na guia e apertando home pra iniciar no topo da tela
    if not clicar_por_coordenada("guiaChrome"):
        print("Guia não encontrada, atualize as coordenadas do guiaChrome")
        time.sleep(5)
        sys.exit()

    print("Verificando token de validação...") 
    
    # Limpa a área de transferência
    pyperclip.copy('')
    
    # Foca no campo "5-Senha" usando a função que você já tem no código
    focar_em_campo('CabecalhoGuiaUC_txtSenha')
    
    time.sleep(0.5) 
    """
    #Comentando por não haver mais necessidade de usar isso pra nada
    # Pressiona Shift + Tab 7 vezes conforme seu teste
    with pyautogui.hold('shift'): 
        pyautogui.press(['tab', 'tab', 'tab']) 
    time.sleep(0.5) 
    with pyautogui.hold('shift'): 
        pyautogui.press(['tab', 'tab', 'tab']) 
    time.sleep(0.5) 
    with pyautogui.hold('shift'): 
        pyautogui.press(['tab', 'tab']) 
    
    pyautogui.press(['home']) 
    time.sleep(0.5) 
    
    # Seleciona tudo e copia
    pyautogui.hotkey('ctrl', 'a')
    time.sleep(0.3)
    pyautogui.hotkey('ctrl', 'c')
    time.sleep(0.3)
    
    # Aperta para o lado para tirar a seleção azul da tela
    pyautogui.press('right') 
    
    texto_copiado = pyperclip.paste().lower()


    pyautogui.press('esc') 
    
    # Verifica se o nome está no texto capturado
    if 'test' in texto_copiado:
        print("Token encontrado. Validação bem-sucedida.") 
        time.sleep(1) 
        return True
    """
    return True

    """
    print("Erro: Validação do usuário falhou.") 
    pyautogui.alert(text='Token inválido...', title='Erro de Validação', button='OK') 
    sys.exit()
    """


def preencher_campo(dado_chave, dados_procedimento): 
    """ 
    Função auxiliar para preencher um campo com dados de teste. 
    """ 
    try: 
        dado = dados_procedimento[dado_chave] 
        print(f"Preenchendo o campo com o valor: {dado}") 
        pyautogui.write(dado, interval=0.1) 
        print("Campo preenchido com sucesso!") 
    except KeyError: 
        print(f"Erro: A chave '{dado_chave}' não foi encontrada nos dados de teste.") 
    except Exception as e: 
        print(f"Ocorreu um erro ao preencher o campo: {e}") 

def preencher_campoProcd(dado_chave, dados_procedimento): 
    """ 
    Função auxiliar para preencher campos usando 'copiar e colar'
    para suportar caracteres especiais e acentos.
    """ 
    try: 
        dado = str(dados_procedimento[dado_chave]) 
        print(f"Preenchendo o campo com o valor: {dado}") 
        
        # Copia o texto para o clipboard e cola no campo
        pyperclip.copy(dado)
        pyautogui.hotkey('ctrl', 'v')
        time.sleep(0.2) # Pequena pausa para garantir a colagem

    except KeyError: 
        print(f"Aviso: O dado '{dado_chave}' não foi encontrado.") 
    except Exception as e: 
        print(f"Erro ao preencher o campo '{dado_chave}': {e}")

        
def preencher_campo_senha(dados_procedimento): 

    """ 
    Função que preenche o campo '5-Senha' usando a técnica de foco via DevTools. 
    """ 
    # 1. Abre o F12 e aguarda o painel carregar
    pyautogui.hotkey('f12')
    time.sleep(1)

    # 2. Abre a busca no Elements e digita o ID específico
    pyautogui.hotkey('ctrl', 'f')
    time.sleep(0.2) 
    pyautogui.typewrite('CabecalhoGuiaUC_txtSenha', interval=0.01)
    
    # 3. Aguarda o highlight do seletor
    time.sleep(0.5)

    # 4. Sai da barra de busca para focar no código do elemento
    pyautogui.press('esc')
    time.sleep(0.2)

    # 5. Abre o menu de contexto (Botão Direito)
    pyautogui.hotkey('shift', 'f10')
    time.sleep(0.3)

    # 6. Desce até a opção 'Focus' (15 vezes) e confirma
    pyautogui.press('up', presses=4, interval=0.05)
    pyautogui.press('enter')
    
    # 7. Curta pausa para garantir o foco no input real da página
    time.sleep(0.1)

    # --- Início da sua lógica original de preenchimento e validação ---
    preencher_campo('5-Senha', dados_procedimento) 
    print("Preenchimento do campo '5-Senha' concluído.") 
    pyautogui.press('tab') 
    time.sleep(1.3) 
    
    if procurar_senha_invalida() == False: 
        print('O campo 5-Senha é válido') 
        return True, "Sucesso" 
    else: 
        print('O campo 5-Senha é inválido') 
        pyautogui.press('enter')
        time.sleep(1)
        limpar_tela() 
        time.sleep(1) 
        return False, "Senha Inválida"

def procurar_senha_invalida(): 

    """ 
    Verifica se a imagem 'senhaInvalida.jpg' está na tela. 
    Retorna True se a imagem for encontrada, e False caso contrário. 
    """ 
    try: 
        # Tenta encontrar a imagem. Se encontrar, a execução continua. 
        pyautogui.locateOnScreen('senhaInvalida.jpg') 
        
        # Se a imagem for encontrada, este bloco é executado. 
        print("A imagem 'senhaInvalida.jpg' foi encontrada.") 
        return True 
    
    except Exception as e: 
        # Se a exceção for capturada (imagem não encontrada), este bloco é executado. 
        print(e) 
        print("Não achei a imagem 'senhaInvalida.jpg'.") 
        return False 
    
def clicar_em_incluir_procedimento():

    """ 
    Função que clica em 'Incluir Procedimento' usando a técnica de foco via DevTools. 
    """ 
    # 1. Abre o F12 e aguarda o painel carregar
    pyautogui.hotkey('f12')
    time.sleep(1)

    # 2. Abre a busca no Elements e digita o ID específico
    pyautogui.hotkey('ctrl', 'f')
    time.sleep(0.2) 
    pyautogui.typewrite('ProcedimentosRealizadosUC1_lnkIncluirProcedimento', interval=0.01)
    
    # 3. Aguarda o highlight do seletor
    time.sleep(0.5)

    # 4. Sai da barra de busca para focar no código do elemento
    pyautogui.press('esc')
    time.sleep(0.2)

    # 5. Abre o menu de contexto (Botão Direito)
    pyautogui.hotkey('shift', 'f10')
    time.sleep(0.3)

    # 6. Desce até a opção 'Focus' (15 vezes) e confirma
    pyautogui.press('up', presses=4, interval=0.05)
    pyautogui.press('enter')
    
    # 7. Curta pausa para garantir o foco no input real da página
    time.sleep(0.1)
    pyautogui.press('enter')
    time.sleep(0.1)

def focar_em_campo_observacao():
    """ 
    Função que foca em 'Observação' usando a técnica de foco via DevTools. 
    """ 
    # 1. Abre o F12 e aguarda o painel carregar
    pyautogui.hotkey('f12')
    time.sleep(1)

    # 2. Abre a busca no Elements e digita o ID específico
    pyautogui.hotkey('ctrl', 'f')
    time.sleep(0.2) 
    pyautogui.typewrite('ProcedimentosRealizadosUC1_txtObservacao', interval=0.01)
    
    # 3. Aguarda o highlight do seletor
    time.sleep(0.5)

    # 4. Sai da barra de busca para focar no código do elemento
    pyautogui.press('esc')
    time.sleep(0.2)

    # 5. Abre o menu de contexto (Botão Direito)
    pyautogui.hotkey('shift', 'f10')
    time.sleep(0.3)

    # 6. Desce até a opção 'Focus' (15 vezes) e confirma
    pyautogui.press('up', presses=4, interval=0.05)
    pyautogui.press('enter')
    
    # 7. Curta pausa para garantir o foco no input real da página
    time.sleep(0.1)    


    '''
    # 1. Abre o F12 e aguarda o painel carregar
    pyautogui.hotkey('f12')
    time.sleep(1)

    # 2. Abre a busca no Elements e digita o ID específico
    pyautogui.hotkey('ctrl', 'f')
    time.sleep(0.2) 
    pyautogui.typewrite('ProcedimentosRealizadosUC1_txtObservacao', interval=0.01)
    
    # 3. Aguarda o highlight do seletor
    time.sleep(0.5)

    # 4. Sai da barra de busca para focar no código do elemento
    pyautogui.press('esc')
    time.sleep(0.2)

    # 5. Abre o menu de contexto (Botão Direito)
    pyautogui.hotkey('shift', 'f10')
    time.sleep(0.3)

    # 6. Desce até a opção 'Focus' (15 vezes) e confirma
    pyautogui.press('down', presses=15, interval=0.05)
    pyautogui.press('enter')
    
    # 7. Curta pausa para garantir o foco no input real da página
    time.sleep(0.1)*//*'''

def focar_em_campo(idCampo):
    """ 
    Função que foca em algum campo recebido por parâmetro usando a técnica de foco via DevTools. 
    """ 
    # 1. Abre o F12 e aguarda o painel carregar
    pyautogui.hotkey('f12')
    time.sleep(1)

    # 2. Abre a busca no Elements e digita o ID específico
    pyautogui.hotkey('ctrl', 'f')
    time.sleep(0.2) 
    pyautogui.typewrite(idCampo, interval=0.01)
    
    # 3. Aguarda o highlight do seletor
    time.sleep(0.5)

    # 4. Sai da barra de busca para focar no código do elemento
    pyautogui.press('esc')
    time.sleep(0.2)

    # 5. Abre o menu de contexto (Botão Direito)
    pyautogui.hotkey('shift', 'f10')
    time.sleep(0.3)

    # 6. Desce até a opção 'Focus' (15 vezes) e confirma
    pyautogui.press('up', presses=4, interval=0.05)
    pyautogui.press('enter')
    
    # 7. Curta pausa para garantir o foco no input real da página
    time.sleep(0.1)    



def preencher_demais_campos(dados_procedimento): 
    """ 
    Função para preencher os campos 4, 8, 16, 17, 18 e 19, e clicar nos botões. 
    """ 
    print("\nIniciando o preenchimento dos próximos campos...") 

    # Passo 1: Campo 4 (Data da Autorização) 
    time.sleep(1) 
    pyautogui.press('tab', presses=5) 
    preencher_campo('4-Data da Autorização (ver email)', dados_procedimento[0]) 
    # Passo 2: Campo 8 (Número da Carteira) 
    print("Apertando TAB 4 vezes para pular para o campo 8...") 
    pyautogui.press('tab', presses=4) 
    preencher_campo('8-Número da Carteira', dados_procedimento[0]) 

    # Passo 3: Botão 'Repetir Dados do Executante' 
    apertar_repetir_dados_executante() 


    # Passo 4: Campo 16
    focar_em_campo('DadosSolicitanteUC_ddlConselhoProfissionalSolicitante')

    time.sleep(1) # Pausa para o menu de clique aparecer 
    pyautogui.write('06') # Digita '0' e '6' 
    print("Preencimento do campo '06-CRM' concluído.") 

    # Passo 5: Campo 17 
    print("Preenchendo o campo fixo 17") 
    pyautogui.press('tab') 
    pyautogui.write('55555') #Mock number for AI training 

    # Passo 6: Campo 18 e seu clique 
    pyautogui.press('tab') 
    pyautogui.press('enter') 
    time.sleep(1) # Pausa para o menu de clique aparecer 
    pyautogui.write('32') 
    pyautogui.press('enter') 

    # Passo 7: Botão e preenchimento do campo 19 (usando teclado) 
    print("\nClicando e preenchendo o campo 19...") 
    pyautogui.press('tab', presses=1) # Pressiona a tecla TAB uma vez 
    time.sleep(1) # Aguarda o foco do teclado ir para o próximo campo 
    # Não precisa mais de reconhecimento de imagem, o foco já está aqui. 
    preencher_campo('19-Codigo CBO', dados_procedimento[0]) 
    pyautogui.press('tab', presses=1) #Pressionada pra fazer o site validar o código cbo 
    time.sleep(3) # Pausa para aguardar o site validar o código cbo 

    # Passo 8: Automação para campos 21 e 22 
    print("\nNavegando e preenchendo campos 21 e 22 via teclado e mouse...") 



    # Campo 21: Selecionando campo 21
    focar_em_campo("DadosSolicitacaoUC1_ddlCaraterAtendimento") 
    # Seleciona a opção com a seta para baixo
    pyautogui.press('down') 

    # Pula para o campo 22 
    pyautogui.press('tab', presses=1) 

    # Preenche o campo 22 com o mesmo valor do campo 4 
    preencher_campo('4-Data da Autorização (ver email)', dados_procedimento[0]) 

    print("Preenchimento dos campos 21 e 22 concluído.") 
    
    # Preenche o primeiro procedimento no campo 24 
    print("\nPreenchendo o primeiro procedimento no campo 24...") 
    pyautogui.press('tab', presses=3) 
    pyautogui.press('enter') 
    pyautogui.write('00') 
    pyautogui.press('enter') 
    time.sleep(0.5) 
    aguardar_tela_carregamento() 
    
    # Campo 25 (Código do Procedimento) 
    print("Apertando SHIFT+TAB 3 vezes para ir para o campo 25...") 
    with pyautogui.hold('shift'): 
        pyautogui.press(['tab', 'tab', 'tab']) 
    preencher_campo('25-Código do Procedimento ou Item assistencial', dados_procedimento[0]) 
    pyautogui.press('tab')
    time.sleep(2)
    aguardar_tela_carregamento()
    
   # --- NOVO: Campo 26 (Descrição do Procedimento) ---
    print("Indo para o campo 26 (Descrição)...")
    with pyautogui.hold('shift'): 
        pyautogui.press(['tab']) 
    # Preenche usando a descrição que buscamos no Excel de referência
    preencher_campoProcd('26-DescProcd', dados_procedimento[0])
    

    # Campo 27 (Qtde Solic.) 
    pyautogui.press('tab') 
    time.sleep(1) # Pausa para o campo 27 carregar 
    aguardar_tela_carregamento()
    preencher_campo('27-Qtde Solic.', dados_procedimento[0]) 

    # Campo 28 (Qtde Aut.) 
    pyautogui.press('tab') 
    preencher_campo('27-Qtde Solic.', dados_procedimento[0]) 
    
    # Inicia o loop para os demais procedimentos 
    tab_presses = 7 
    # FIX: Renomeando a variável para evitar conflito. 
    for i, procedimento_atual in enumerate(dados_procedimento[1:]): 

        print("\nAdicionando e preenchendo o próximo procedimento...") 
        # Clica no botão 'Incluir Procedimento com Lupa' com teclado 
        pyautogui.press('tab', presses=2) 
        pyautogui.press('enter') 
        time.sleep(1.5) # Pausa para a nova linha aparecer 
        pyautogui.press('tab') # Seletor base do mouse 

        # Navega para o campo 24 da nova linha 
        print(f"Pressionando TAB {tab_presses} vezes para ir para o campo 24 da nova linha...") 
        pyautogui.press('tab', presses=tab_presses) 
        
        # Preenche o campo 24 com '00' 
        time.sleep(1)  
        pyautogui.press('enter') 
        pyautogui.write('00') 
        pyautogui.press('enter') 
        time.sleep(0.5) 
        aguardar_tela_carregamento() 
        
        # Campo 25 (Código do Procedimento) 
        print("Apertando SHIFT+TAB 3 vezes para ir para o campo 25...") 
        with pyautogui.hold('shift'): 
            pyautogui.press(['tab', 'tab', 'tab']) 
        preencher_campo('25-Código do Procedimento ou Item assistencial', procedimento_atual) 
        pyautogui.press('tab')
        time.sleep(2)
        aguardar_tela_carregamento()
        
    # --- NOVO: Campo 26 (Descrição do Procedimento) ---
        print("Indo para o campo 26 (Descrição)...")
        with pyautogui.hold('shift'): 
            pyautogui.press(['tab']) 
        # Preenche usando a descrição que buscamos no Excel de referência
        preencher_campoProcd('26-DescProcd', procedimento_atual)


        # Campo 27 (Qtde Solic.) 
        pyautogui.press('tab') 
        time.sleep(1) # Pausa para o campo 27 carregar 
        aguardar_tela_carregamento()
        preencher_campo('27-Qtde Solic.', procedimento_atual) 

        # Campo 28 (Qtde Aut.) 
        print("Apertando TAB e preenchendo o campo 28...") 
        pyautogui.press('tab') 
        preencher_campo('27-Qtde Solic.', procedimento_atual) 
        time.sleep(0.5) # Pausa para respirar 

        
        # Incrementa o contador de tabs para a próxima iteração 
        tab_presses += 7 

    print("\nTodos os campos foram preenchidos e a automação de repetição foi concluída!") 

    print("Selecionando e Preenchendo campo fixo 32") 
    pyautogui.press('tab', presses=5) 
    pyautogui.press('enter') 
    pyautogui.write('03') 
    pyautogui.press('enter') 
    time.sleep(0.5) 

    print("Selecionando e preenchendo campo fixo 33") 
    focar_em_campo('DadosAtendimentoUC1_ddlIndicacaoAcidente')
    
    pyautogui.write('9') 
    time.sleep(0.5) 


    print("Selecionando e preenchendo campo fixo 91") 

    pyautogui.press('tab', presses=3) 
    pyautogui.press('enter')
    pyautogui.press('down')
    pyautogui.press('down')
    pyautogui.press('enter')
    # um dois tres tabs enter seta baixo enter

    #####  Começando a próxima iteração de repetições (do tipo fixas) 
    print("Começando a próxima iteração de repetições") 

    print("Selecionando e digitando o campo 37") 
    time.sleep(1) 
    pyautogui.press('tab', presses=2)
    # FIX: Usando a primeira entrada da lista original, que é o dado correto. 
    preencher_campo('4-Data da Autorização (ver email)', dados_procedimento[0])

    time.sleep(1)

    # Preenche o primeiro procedimento no campo 40 
    print("\nPreenchendo o primeiro procedimento no campo 40...") 
    pyautogui.press('tab', presses=3) #Pra selecionar o campo 
    pyautogui.press('enter') 
    pyautogui.write('00') 
    pyautogui.press('enter') 
    time.sleep(1) 

    # Apertando SHIFT+TAB 3 vezes para ir para o campo 41... que é igual ao 25 
    print("Preenchendo o campo 41-Cód.Proc") 
    with pyautogui.hold('shift'): 
        pyautogui.press(['tab', 'tab', 'tab']) 
    # FIX: Usando a primeira entrada da lista original, que é o dado correto. 
    preencher_campo('25-Código do Procedimento ou Item assistencial', dados_procedimento[0]) 
    pyautogui.press('tab') 
    time.sleep(2.6) # Pausa para o campo carregar 
    aguardar_tela_carregamento()

    #Preenchendo o 42, que é identico ao 26
    with pyautogui.hold('shift'): 
        pyautogui.press(['tab']) 
    preencher_campoProcd('26-DescProcd', dados_procedimento[0])
    pyautogui.press('tab')
    time.sleep(1)
    aguardar_tela_carregamento()

    # Campo 43 (Qtde Solic.) 
    print("\nPreenchendo o campo 43") 
    # FIX: Usando a primeira entrada da lista original, que é o dado correto. 
    preencher_campo('27-Qtde Solic.', dados_procedimento[0]) 
    pyautogui.press('tab') 
    time.sleep(1.2) # Pausa para o campo 43 carregar 

    print("Preenchendo o campo fixo 46") 
    pyautogui.press('tab', presses=2) 
    pyautogui.write('1') 
    pyautogui.press('tab') 
    time.sleep(1.2) # Pausa para o campo 46 carregar 

    print("Preenchendo campo 47") 

    focar_em_campo_observacao()
    time.sleep(1.2)
    aguardar_tela_carregamento()

    with pyautogui.hold('shift'): 
        pyautogui.press(['tab', 'tab', 'tab', 'tab']) 
    time.sleep(0.6)
    # FIX: Usando a primeira entrada da lista original, que é o dado correto. 
    preencher_campo('47-Valor Unitário', dados_procedimento[0]) 
    pyautogui.press('tab')  
    time.sleep(1.6) # Pausa para o campo 47 carregar 


    # Inicia o loop para os demais procedimentos 
    # FIX: Usando uma nova variável para iterar sobre a lista. 
    for i, procedimento_atual in enumerate(dados_procedimento[1:]): 
        ''' 
        print("Adicionando o próximo procedimento") 
        with pyautogui.hold('shift'): 
            pyautogui.press('tab', presses=5) 
        time.sleep(1.2) # Pausa pra não bugar o site 
        with pyautogui.hold('shift'): 
            pyautogui.press('tab', presses=5)  
        pyautogui.press('enter')  
        time.sleep(1.2) # Pausa para a janela carregar 
        ''' 

        print("Adicionando o próximo procedimento") 

        clicar_em_incluir_procedimento()

        time.sleep(1.2) # Pausa de praste 

        print("Selecionando e digitando o campo 37") 

        focar_em_campo_observacao()
        time.sleep(2.4)
        aguardar_tela_carregamento()

        with pyautogui.hold('shift'): 
            pyautogui.press('tab', presses=5) 
        time.sleep(0.7) # Pausa pq é mto comando repetido e a tela buga se for rápido demais 
        with pyautogui.hold('shift'): 
            pyautogui.press('tab', presses=5) 
        time.sleep(0.7) # Pausa pq é mto comando repetido e a tela buga se for rápido demais 
        with pyautogui.hold('shift'): 
            pyautogui.press('tab', presses=5) 
        time.sleep(0.7) # Pausa pq é mto comando repetido e a tela buga se for rápido demais 
        preencher_campo('4-Data da Autorização (ver email)', procedimento_atual) 

        time.sleep(1)

        print("\nPreenchendo o próximo procedimento no campo 40...") 
        pyautogui.press('tab', presses=3) #Pra selecionar o campo 
        pyautogui.press('enter') 
        pyautogui.write('00') 
        pyautogui.press('enter') 
        time.sleep(1) 

        # Apertando SHIFT+TAB 3 vezes para ir para o campo 41... que é igual ao 25 
        print("Preenchendo o campo 41-Cód.Proc") 
        with pyautogui.hold('shift'): 
            pyautogui.press(['tab', 'tab', 'tab']) 
        # FIX: Usando a primeira entrada da lista original, que é o dado correto. 
        preencher_campo('25-Código do Procedimento ou Item assistencial', procedimento_atual) 
        pyautogui.press('tab') 
        time.sleep(2.6) # Pausa para o campo carregar 
        aguardar_tela_carregamento()

        #Preenchendo o 42, que é identico ao 26
        with pyautogui.hold('shift'): 
            pyautogui.press(['tab']) 
        preencher_campoProcd('26-DescProcd', procedimento_atual)
        pyautogui.press('tab') 
        time.sleep(1)
        aguardar_tela_carregamento()

        # Campo 43 (Qtde Solic.) 
        print("\nPreenchendo o campo 43") 
        # FIX: Usando a primeira entrada da lista original, que é o dado correto. 
        preencher_campo('27-Qtde Solic.', procedimento_atual) 
        pyautogui.press('tab') 
        time.sleep(1.2) # Pausa para o campo 43 carregar 

        print("Preenchendo o campo fixo 46") 
        pyautogui.press('tab', presses=2) 
        pyautogui.write('1') 
        pyautogui.press('tab') 
        time.sleep(1.2) # Pausa para o campo 46 carregar 

        print("Preenchendo campo 47") 

        focar_em_campo_observacao()
        time.sleep(1.2)
        aguardar_tela_carregamento() 

        with pyautogui.hold('shift'): 
            pyautogui.press(['tab', 'tab', 'tab', 'tab']) 
        time.sleep(0.6)
        preencher_campo('47-Valor Unitário', procedimento_atual) 
        pyautogui.press('tab')  
        time.sleep(1.6) # Paus 
        
def verificar_responsividade_site():
    print("Verificando se a página continua responsiva...")
    
    # 1. Aperta page up 3 vezes para garantir que estamos no topo da página
    pyautogui.press('pgup', presses=3, interval=0.1)
    time.sleep(1)
    
    # 2. Clica 2 vezes nas coordenadas de guiaSP
    if "guiaSP" in coords:
        x = coords["guiaSP"]["x"]
        y = coords["guiaSP"]["y"]
        # clicks=2 faz um duplo clique rápido, perfeito para selecionar a palavra inteira
        pyautogui.click(x, y, clicks=2, interval=0.1) 
        time.sleep(0.5)
    else:
        raise Exception("Coordenada 'guiaSP' não encontrada no arquivo coordenadas.json.")
        
    # 3. Copia para a área de transferência
    pyperclip.copy('') # Limpa o clipboard primeiro para evitar falso positivo
    pyautogui.hotkey('ctrl', 'c')
    time.sleep(0.3)
    
    # Tira a seleção da tela apertando a seta pro lado para não atrapalhar o preenchimento
    pyautogui.press('right')
    time.sleep(0.2)
    
    texto_copiado = pyperclip.paste().strip().lower()
    
    # 4. Verifica se conseguiu copiar a palavra "guia"
    if "guia" in texto_copiado:
        print("Site respondendo normalmente! Continuando a automação...")
        return True
    else:
        # 5. Se travar, levanta o erro. Isso vai acionar o Recovery automático no outro arquivo!
        raise Exception("Deu algo errado, favor relogar e reiniciar o robô que ele continuará de onde parou")
    
def executar_automacao(dados_para_preencher, quantidade_procedimentos): 
    """
    Função principal de automação. Preenche os campos, salva e finaliza a guia.
    
    Retorna:
    - automacao_ok (bool): True se a automação foi totalmente bem-sucedida.
    - motivo_falha (str/None): Descrição do erro em caso de falha, ou None em caso de sucesso.
    - numero_guia (str/None): O número da guia gerada em caso de sucesso, ou None em caso de falha.
    """
    # Para modificar a variável global, precisamos declará-la 
    global _VALIDACAO_FEITA  


    #TESTE SALVAR FINALIZAR DIRETO

    #salvar_finalizar()

    #input("pausa obrigatória")


    
    pyautogui.press('pgup', presses=6) 
    time.sleep(2) 
    
    # Valores de retorno padrão em caso de lista de dados vazia
    if not dados_para_preencher:
        return False, "Dados de preenchimento não fornecidos.", None

    # CHECKPOINT DE VALIDAÇÃO ÚNICA: 
    if not _VALIDACAO_FEITA: 
        verificar_validacao() 
        _VALIDACAO_FEITA = True # Seta a flag para True após a primeira execução bem-sucedida 


    # --- VERIFICAÇÃO DE RESPONSIVIDADE ANTES DE CADA CLIENTE ---
    verificar_responsividade_site()
    # -----------------------------------------------------------

    print("Iniciando a automação. Certifique-se de que a página da GEAP está visível.") 
    print('se você mover o mouse para o canto superior esquerdo da tela, o programa vai parar. Isso é útil para cancelar a automação.') 

    time.sleep(3) # Pausa inicial para dar tempo de abortar o programa. 

    # 1. Preenche o campo senha
    sucesso_senha, motivo_falha_senha = preencher_campo_senha(dados_para_preencher[0]) 
    
    if not sucesso_senha: 
        print(f"Senha inválida. Pulando para o próximo cliente. Motivo: {motivo_falha_senha}") 
        # Falha na Senha: Retorna 3 valores: False (não ok), motivo_falha, None (sem guia)
        return False, motivo_falha_senha, None

    # 2. Preenche os demais campos
    preencher_demais_campos(dados_para_preencher) 

    time.sleep(1) 
    pyautogui.press('pgup', presses=6) 
    time.sleep(1) 
    
    # 3. Salvar e Finalizar
    # O retorno é (bool: sucesso_guia, str: motivo_falha OU numero_guia)
    sucesso_guia, motivo_guia_ou_numero = salvar_finalizar()
    
    if sucesso_guia:
        # Sucesso na automação: O segundo valor é o número da guia
        numero_guia = motivo_guia_ou_numero
        motivo_falha = None # Em caso de sucesso, o motivo da falha é None
        return True, motivo_falha, numero_guia
    else:
        # Falha na automação: O segundo valor é o motivo da falha
        motivo_falha = motivo_guia_ou_numero 
        numero_guia = None # Em caso de falha, o número da guia é None
        return False, motivo_falha, numero_guia


# --- Código para execução --- 
if __name__ == "__main__": 
    # Quando o outro arquivo de leitura de planilha for criado, ele 
    # vai importar este módulo e chamar a função executar_automacao, 
    # passando os dados da planilha como argumentos. 
    # 
    # Por exemplo (refletindo os 3 outputs esperados): 
    # automacao_ok, motivo_falha, numero_guia = executar_automacao(dados_da_planilha, quantidade_da_planilha) 
    # if automacao_ok: 
    #   print(f"Guia gerada com sucesso: {numero_guia}") 
    # else: 
    #   print(f"Erro na automação: {motivo_falha}") 
    
    # Por enquanto, vamos manter um exemplo de dados para teste, 
    # para que o script possa ser executado de forma independente. 

    QUANTIDADE_PROCEDIMENTOS_EXEMPLO = 4 
    
#By Est&Zrs 
