# GEAP TISS Billing Data Processor

Python utility that reads medical billing spreadsheets (`.xlsx`), maps procedure codes against `codigosProcedimentos.xlsx`, and structures patient and procedure records for GEAP SP/SADT guides.

## Project Structure

- `geap_ler_planilhas.py` — Reads input spreadsheets from `RodarEstes/`, enriches procedure codes with descriptions from `codigosProcedimentos.xlsx`, and handles batch state/error tracking.
- `geap_medhome_main.py` — Legacy UI automation module (`pyautogui`) being deprecated in favor of direct TISS XML generation.
- `codigosProcedimentos.xlsx` — Reference lookup table mapping TUSS/procedure codes to their official descriptions.
- `RodarEstes/` — Input directory containing sanitized mock billing spreadsheets.

- All spreadsheets in RodarEstes/ contain mock/synthetic patient data for testing.
- `geap_medhome_main.py` requires a local Windows GUI session and is legacy code being replaced. Do not execute it in headless environments; only test the XML generation module and pytest suite.

## Setup

Install the required dependencies:

```bash
pip install openpyxl lxml pytest